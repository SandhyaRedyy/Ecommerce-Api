package com.eazydeals.helpers;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionProvider {

    private static Connection connection;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Load MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Create connection
                String url = "jdbc:mysql://localhost:3306/eazydeals?useSSL=false&serverTimezone=UTC";
                String user = "root";
                String password = "Vicky@123";

                connection = DriverManager.getConnection(url, user, password);
                System.out.println("✅ Database connected.");
            }
        } catch (Exception e) {
            System.out.println("❌ Failed to connect to database:");
            e.printStackTrace();
        }

        return connection;
    }
}
