package com.eazydeals.servlets;

import com.eazydeals.WishlistDao;
import com.eazydeals.entities.Wishlist;
import com.eazydeals.helpers.ConnectionProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/WishlistServlet")
public class WishlistServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int uid = Integer.parseInt(request.getParameter("uid"));
            int pid = Integer.parseInt(request.getParameter("pid"));
            String op = request.getParameter("op");

            WishlistDao dao = new WishlistDao(ConnectionProvider.getConnection());

            if (op != null) {
                switch (op.trim()) {
                    case "add":
                        dao.addToWishlist(new Wishlist(uid, pid));
                        response.sendRedirect("products.jsp");
                        break;
                    case "remove":
                        dao.deleteWishlist(uid, pid);
                        response.sendRedirect("products.jsp");
                        break;
                    case "delete":
                        dao.deleteWishlist(uid, pid);
                        response.sendRedirect("profile.jsp");
                        break;
                    default:
                        response.sendRedirect("error.jsp");
                }
            } else {
                response.sendRedirect("error.jsp");
            }
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
