package com.eazydeals.servlets;

import com.eazydeals.entities.User;
import com.eazydeals.entities.Message;
import com.eazydeals.helpers.ConnectionProvider;
import com.eazydeals.helpers.MailMessenger;
import com.eazydeals.UserDao;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            String name = request.getParameter("user_name");
            String email = request.getParameter("user_email");
            String password = request.getParameter("user_password");
            String phone = request.getParameter("user_mobile_no");
            String gender = request.getParameter("gender");
            String address = request.getParameter("user_address");
            String city = request.getParameter("city");
            String pincode = request.getParameter("pincode");
            String state = request.getParameter("state");

            User user = new User(name, email, password, phone, gender, address, city, pincode, state);
            UserDao dao = new UserDao(ConnectionProvider.getConnection());
            boolean result = dao.saveUser(user);

            HttpSession session = request.getSession();
            Message msg;
            if (result) {
                msg = new Message("Registration Successful!", "success", "alert-success");
                MailMessenger.successfullyRegister(name, email);
            } else {
                msg = new Message("Something went wrong! Try again.", "error", "alert-danger");
            }
            session.setAttribute("message", msg);
            response.sendRedirect("register.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}