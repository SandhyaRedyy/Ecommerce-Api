package com.eazydeals.servlets;

import com.eazydeals.OrderDao;
import com.eazydeals.UserDao;
import com.eazydeals.entities.Order;
import com.eazydeals.helpers.ConnectionProvider;
import com.eazydeals.helpers.MailMessenger;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet("/UpdateOrderServlet")
public class UpdateOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            int oid = Integer.parseInt(request.getParameter("oid"));
            String status = request.getParameter("status");

            OrderDao orderDao = new OrderDao(ConnectionProvider.getConnection());
            orderDao.updateOrderStatus(oid, status);

            if (status != null && (status.equals("Shipped") || status.equals("Out For Delivery"))) {
                Order order = orderDao.getOrderById(oid);
                UserDao userDao = new UserDao(ConnectionProvider.getConnection());
                MailMessenger.orderShipped(
                    userDao.getUserName(order.getUserId()),
                    userDao.getUserEmail(order.getUserId()),
                    order.getOrderId(),
                    order.getDate().toString()
                );
            }

            response.sendRedirect("display_orders.jsp");
        } catch (Exception e) {
            response.sendRedirect("error.jsp");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}